/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificarecupero;

/**
 *
 * @author decapitani_alessandr
 */
public class JDatiCondivisi {
    
    public String stringa1;
    public String stringa2;
    public String stringa3;
    public String stringa4;
    public String stringa5;
    public String stringa6;
    public String stringa7;
    
    public JDatiCondivisi(String stringa1, String stringa2, String stringa3, String stringa4, String stringa5, String stringa6, String stringa7){
        this.stringa1=stringa1;
        this.stringa2=stringa2;
        this.stringa3=stringa3;
        this.stringa4=stringa4;
        this.stringa5=stringa5;
        this.stringa6=stringa6;
        this.stringa7=stringa7;
    }
    
    
}
