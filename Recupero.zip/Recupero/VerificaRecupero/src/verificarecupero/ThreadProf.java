/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificarecupero;

/**
 *
 * @author decapitani_alessandr
 */
public class ThreadProf extends Thread {

    public ThreadProf() {
    }
    
    public String cerca(String classe, String OrarioProf){
       
        Integer c=0;
        Integer i = 0;
        String ris="";
        
        while( i < OrarioProf.length()){
        
            if(OrarioProf.substring(i,i+2) == ",.")
                
                i+=2;
                
            else{
                if(classe == OrarioProf.substring(i, i+3)){
                
                    i+=3;
                    c++;
                }
    }
    }
        if(c > 0)
            ris = classe;
        
        return classe;
        
    }
    
}
